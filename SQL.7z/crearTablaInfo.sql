CREATE TABLE informacion(
    id int(255) auto_increment not null,
    `title` varchar(255) not null,
    `group` varchar(255) not null,
    `year` int(255) not null,
    `genre` varchar(255) not null,    
    CONSTRAINT pk_songs PRIMARY KEY(id)
)ENGINE=innoDb;